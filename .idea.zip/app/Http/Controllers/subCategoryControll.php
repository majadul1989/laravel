<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;
use App\categoryModel;
use App\subCategoryModel;
use Illuminate\Http\Request;

class subCategoryControll extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function subcategory()
    {
        $opCategory = categoryModel::all();
        return view('subCategory')->with('opCategory', $opCategory);
           
        

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data =[
    'subname' =>Input::get('_subname'),
    'sub_cat_id' =>Input::get('sub_cat_id'),
    ];
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $data =[
    'subname' =>Input::get('_subname'),
    'sub_cat_id' =>Input::get('sub_cat_id')
    ];

    $insert = subCategoryModel::create($data);
    if ($insert) {
        return redirect()->back()->with('success', 'Data Saved');
    }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
