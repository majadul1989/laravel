<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class categoryModel extends Model
{
    protected $table = "category";
    protected $fillable = [
    'name', 'create_at',
    ];
}
