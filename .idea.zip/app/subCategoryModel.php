<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class subCategoryModel extends Model
{
    protected $table = 'cubcategory';
    protected $fillable = [
    'subname', 'sub_cat_id', 'created_at',
    ];
}
