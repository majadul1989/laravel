<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-dinger alert-dismissible" role="alert">
            <strong>Whoops</strong> There were some problems with you inputs.<br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($error); ?>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>
            <div class="panel panel-default ">
            <form action="" method="POST" class="form-inline">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <select name="sub_cat_id" class="form-control">
                <?php $__currentLoopData = $opCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $showCat): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <option value="<?php echo e($showCat->id); ?>"><?php echo e($showCat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</select>
                <input type="text" name="_subname" class="form-control">
                <input type="submit" class="btn btn-warning" name="_submit" value="add">
            </form>
            </div>



        </div>
    </div>



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>