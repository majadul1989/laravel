@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        @if (count($errors) > 0)
        <div class="alert alert-dinger alert-dismissible" role="alert">
            <strong>Whoops</strong> There were some problems with you inputs.<br>
            <ul>
                @foreach($errors->all() as $error)
                <li>{{$error}}
                </li>
                @endforeach
            </ul>
        </div>
        @endif
        @if(Session::has('success'))
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          {{Session::get('success')}}
        </div>
        @endif
            <div class="panel panel-default ">
            <form action="" method="POST" class="form-inline">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="text" name="_name" class="form-control">
                <input type="submit" class="btn btn-warning" name="_submit" value="add">
            </form>
            </div>

<table class="table">
@foreach ($category as $key => $showCat)
    <tr>
        <td>{{$showCat->name}}</td>
    </tr>
    
@endforeach
</table>

        </div>
    </div>



</div>
@endsection